package com.example.project.heartbeat.util;

/**
 * Created by balaji on 14/03/16.
 */
public interface TaskDelegate {
    public void taskCompletionResult(String result);

}
